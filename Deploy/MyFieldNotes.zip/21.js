
Form1.innerHTML=[  "<div id='HTMLview1_scroller' class=''   style='font-size:13px; font-family:helvetica; font-style:normal; font-weight:normal; color:black; border-style:groove;' name=''><div id='HTMLview1' style='overflow:auto; background-color:white; height:auto; min-width:276px;'></div></div>",
  "<input type='button' id='Button1' class='nsbbutton'   style='font-size:12px; font-family:helvetica; font-style:normal; font-weight:bold; color:; background-color:; ' name='' value='Adicionar Notes' data-role='none'>",
  "<textarea id='TextArea1' class='' name=''  style='text-align:left; font-size:13px; font-family:helvetica; font-style:normal; font-weight:normal; color:black; background-color:white;-webkit-overflow-scrolling:touch; '   autocorrect='on'  autocomplete='on'  autocapitalize='on'  placeholder='Digite seu texto aqui' data-role='none'></textarea>",
  NSB.HeaderBar_jqm("TitleBar1", "Meus Notes", "Novo", "star", "Opções", "arrow-r", " data-theme=c style='' class=' ' "),
  "<label id='Label1' class='graytitle' style='text-align:left;  font-size:16px; font-family:helvetica; font-style:normal; font-weight:bold; color:black; background-color:transparent; border-style:;border-color:transparent;border-width:1px; ' >Label</label>",
  ].join('');
