
Form3.innerHTML=[  NSB.HeaderBar_jqm("TitleBar3", "Email", "Voltar", "arrow-l", "", "false", " data-theme=c style='' class=' ' "),
  NSB.MultiInput("MultiInput1", 2, "bigfield", "Para,Assunto", "", "texto,texto", "", " style=  ", false),
  "<input type='button' id='Button2' class='nsbbutton'   style='font-size:12px; font-family:helvetica; font-style:normal; font-weight:bold; color:; background-color:; ' name='' value='Button' data-role='none'>",
  "<div id='HTMLview2_scroller' class=''   style='font-size:13px; font-family:helvetica; font-style:normal; font-weight:normal; color:black; border-style:groove;' name=''><div id='HTMLview2' style='overflow:auto; background-color:white; height:auto; min-width:271px;'></div></div>",
  "<label id='Label3' class='graytitle' style='text-align:left;  font-size:16px; font-family:helvetica; font-style:normal; font-weight:bold; color:black; background-color:transparente; border-style:;border-color:transparent;border-width:1px; ' >Etiqueta</label>",
  ].join('');
