
Form2.innerHTML=[  NSB.Checkbox('CheckBox1', 300, 'Exibir Data, Auto-Limar Texto, Auto-Capitalizar,Auto-Completar,Auto-Corre\u00E7\u00E3o,GPS Coordinates', style='' ),
  "<label id='Label2' class='graytitle' style='text-align:left;  font-size:16px; font-family:helvetica; font-style:normal; font-weight:bold; color:black; background-color:transparente; border-style:;border-color:transparent;border-width:1px; ' >Exportar Notas por:</label>",
  NSB.HeaderBar_jqm("TitleBar2", "Configurações", "Voltar", "arrow-l", "", "false", " data-theme=c style='' class=' ' "),
  NSB.ButtonBar("ButtonBar1", "true", "Email, Impressão", "0", " style= "),
  ].join('');
